### install Ansible on Oracle Linux 8.6

Install the packages under epel first.
rpm -ivh *rpm

Then Install the packages under ansible directory.

Git directory are optional to install.